# Simples Nacional App - Brandão Contabilidade
Aplicativo completo para cálculo do DAS com Fator R, retenções e relatórios automáticos.
