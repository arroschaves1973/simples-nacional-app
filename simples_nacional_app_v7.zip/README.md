# App Simples Nacional - Brandão Contabilidade
Aplicativo para cálculo do DAS, fator R, retenções e auditoria.

✅ Desenvolvido para uso via Web no Streamlit Cloud.
📧 Contato: adm@brandaocontador.com.br