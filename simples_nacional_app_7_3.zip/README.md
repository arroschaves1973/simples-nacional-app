Versão 7.3 com campos detalhados da folha de pagamento incluídos no cálculo do Fator R.
