App completo para Simples Nacional com análise de Fator R, retenções e auditoria de DAS.
